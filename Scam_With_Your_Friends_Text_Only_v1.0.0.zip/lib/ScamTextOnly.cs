using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using Mono.Cecil;
using Mono.Cecil.Cil;

public static class ScamTextOnly
{
    public static int Main(string[] args)
    {
        try
        {
            if (args.Length != 2 && args.Length != 4)
                throw new ArgumentException("Укажите исходный файл и путь результата.");
            var original = File.ReadAllBytes(args[0]);
            var patched = args.Length == 4 ? PatchWithMenu(original, args[2], args[3]) : Patch(original);
            using (var output = new FileStream(args[1], FileMode.CreateNew))
                output.Write(patched, 0, patched.Length);
            Console.WriteLine("SHA256=" + Hash(patched));
            return 0;
        }
        catch (Exception error)
        {
            Console.Error.WriteLine(error.Message);
            return 1;
        }
    }

    public static byte[] PatchWithMenu(byte[] original, string runtimePath, string managedPath)
    {
        var patched = Patch(original);
        using (var resolver = new DefaultAssemblyResolver())
        {
            resolver.AddSearchDirectory(managedPath);
            resolver.AddSearchDirectory(Path.GetDirectoryName(Path.GetFullPath(runtimePath)));
            var reading = new ReaderParameters { AssemblyResolver = resolver };
            using (var runtime = AssemblyDefinition.ReadAssembly(runtimePath, reading))
            using (var assembly = AssemblyDefinition.ReadAssembly(new MemoryStream(patched), reading))
            {
                var startup = runtime.MainModule.Types.Single(t => t.FullName == "ScamTextOnlyMod.MenuBootstrap")
                    .Methods.Single(m => m.Name == "Ensure" && m.Parameters.Count == 0);
                var owner = assembly.MainModule.Types.Single(t => t.Name == "PocketTtsSingleton");
                var awake = Method(owner, "Awake", 0);
                var imported = assembly.MainModule.ImportReference(startup);
                var il = awake.Body.GetILProcessor();
                il.InsertBefore(awake.Body.Instructions[0], il.Create(OpCodes.Call, imported));
                using (var output = new MemoryStream())
                {
                    assembly.Write(output, new WriterParameters { Timestamp = 0 });
                    var result = output.ToArray();
                    Validate(result);
                    return result;
                }
            }
        }
    }

    public static byte[] Patch(byte[] original)
    {
        var result = (byte[])original.Clone();
        var ranges = new List<Tuple<int, int>>();
        using (var assembly = AssemblyDefinition.ReadAssembly(new MemoryStream(original)))
        {
            var owner = assembly.MainModule.Types.Single(t => t.Name == "PocketTtsSingleton");
            var enqueue = Method(owner, "EnqueueSpeak", 6);
            var start = Method(owner, "Start", 0);
            var warmup = Method(owner, "WarmUpVoice", 1);
            RequireCall(enqueue, "Enqueue");
            RequireCall(enqueue, "ProcessSpeakQueue");
            RequireCall(start, "InitModel");
            RequireCall(warmup, "EnqueueWarmUpVoice");
            var request = owner.NestedTypes.Single(t => t.Name == "TtsRequest");
            var publish = Method(owner, "PublishFailedTranscript", 1);
            var complete = Method(owner, "ReportTrackedCompletion", 2);
            if (!complete.IsStatic || publish.IsStatic || enqueue.Body.MaxStackSize < 4)
                throw new InvalidDataException("Неожиданная структура обработки реплик.");
            var blank = Reference(enqueue, "IsNullOrWhiteSpace");
            var clock = Reference(enqueue, "get_realtimeSinceStartupAsDouble");
            var code = new List<byte>();
            Emit(code, 0x03);
            Emit(code, 0x28, blank);
            Emit(code, 0x2C, 0x01, 0x2A);
            Emit(code, 0x02);
            Emit(code, 0x73, Method(request, ".ctor", 0));
            Emit(code, 0x25);
            Emit(code, 0x28, clock);
            Emit(code, 0x7D, Field(request, "EnqueuedAt"));
            StoreArgument(code, request, "Text", 1);
            StoreArgument(code, request, "VoicePath", 2);
            StoreArgument(code, request, "CallNetId", 3);
            StoreArgument(code, request, "CompletionToken", 4);
            StoreArgument(code, request, "LanguageCode", 5);
            StoreArgument(code, request, "IsFiller", 6);
            var current = Field(owner, "currentRequest");
            Emit(code, 0x7D, current);
            Emit(code, 0x02, 0x02);
            Emit(code, 0x7B, current);
            Emit(code, 0x28, publish);
            Emit(code, 0x02);
            Emit(code, 0x7B, current);
            Emit(code, 0x17);
            Emit(code, 0x28, complete);
            Emit(code, 0x02, 0x14);
            Emit(code, 0x7D, current);
            Emit(code, 0x2A);
            Replace(result, enqueue, code.ToArray(), ranges);
            Replace(result, start, new byte[] { 0x2A }, ranges);
            Replace(result, warmup, new byte[] { 0x2A }, ranges);
        }
        for (int i = 0; i < original.Length; i++)
            if (original[i] != result[i] && !ranges.Any(r => i >= r.Item1 && i < r.Item1 + r.Item2))
                throw new InvalidDataException("Изменение за пределами выбранных методов.");
        Validate(result);
        Console.WriteLine("Режим только текста подготовлен.");
        return result;
    }

    private static void Validate(byte[] bytes)
    {
        using (var assembly = AssemblyDefinition.ReadAssembly(new MemoryStream(bytes)))
        {
            var owner = assembly.MainModule.Types.Single(t => t.Name == "PocketTtsSingleton");
            var enqueue = Method(owner, "EnqueueSpeak", 6);
            RequireCall(enqueue, "PublishFailedTranscript");
            RequireCall(enqueue, "ReportTrackedCompletion");
            if (enqueue.Body.Instructions.Any(i => i.Operand is MethodReference &&
                new[] { "ProcessSpeakQueue", "Enqueue", "Prompt", "InitModel" }
                    .Contains(((MethodReference)i.Operand).Name)))
                throw new InvalidDataException("В изменённом методе остался запуск озвучки.");
            foreach (var name in new[] { "Start", "WarmUpVoice" })
            {
                var method = Method(owner, name, name == "Start" ? 0 : 1);
                if (method.Body.Instructions[0].OpCode != OpCodes.Ret ||
                    method.Body.Instructions.Skip(1).Any(i => i.OpCode != OpCodes.Nop && i.OpCode != OpCodes.Ret))
                    throw new InvalidDataException("Не удалось отключить подготовку голоса.");
            }
        }
    }

    private static MethodDefinition Method(TypeDefinition owner, string name, int arguments)
    {
        return owner.Methods.Single(m => m.Name == name && m.Parameters.Count == arguments);
    }

    private static FieldDefinition Field(TypeDefinition owner, string name)
    {
        return owner.Fields.Single(f => f.Name == name);
    }

    private static MethodReference Reference(MethodDefinition method, string name)
    {
        return method.Body.Instructions.Select(i => i.Operand).OfType<MethodReference>()
            .First(m => m.Name == name);
    }

    private static void RequireCall(MethodDefinition method, string name)
    {
        if (!method.Body.Instructions.Any(i => i.Operand is MethodReference &&
            ((MethodReference)i.Operand).Name == name))
            throw new InvalidDataException("Исходный метод изменён: " + method.FullName);
    }

    private static void StoreArgument(List<byte> code, TypeDefinition request, string field, byte argument)
    {
        Emit(code, 0x25);
        if (argument <= 3)
            Emit(code, (byte)(0x02 + argument));
        else
            Emit(code, 0x0E, argument);
        Emit(code, 0x7D, Field(request, field));
    }

    private static void Emit(List<byte> code, params byte[] bytes)
    {
        code.AddRange(bytes);
    }

    private static void Emit(List<byte> code, byte operation, IMetadataTokenProvider target)
    {
        code.Add(operation);
        code.AddRange(BitConverter.GetBytes(target.MetadataToken.ToInt32()));
    }

    private static void Replace(byte[] image, MethodDefinition method, byte[] code,
        List<Tuple<int, int>> ranges)
    {
        if (method.Body.ExceptionHandlers.Count != 0)
            throw new InvalidDataException("В выбранном методе появились обработчики исключений.");
        int header = RvaOffset(image, (uint)method.RVA);
        int start;
        int size;
        if ((image[header] & 3) == 2)
        {
            start = header + 1;
            size = image[header] >> 2;
        }
        else if ((image[header] & 3) == 3)
        {
            start = header + ((BitConverter.ToUInt16(image, header) >> 12) * 4);
            size = BitConverter.ToInt32(image, header + 4);
        }
        else
            throw new InvalidDataException("Неизвестный формат тела метода.");
        if (code.Length > size)
            throw new InvalidDataException("Новый метод не помещается в исходную сборку.");
        Array.Clear(image, start, size);
        Buffer.BlockCopy(code, 0, image, start, code.Length);
        image[start + size - 1] = 0x2A;
        ranges.Add(Tuple.Create(start, size));
    }

    private static int RvaOffset(byte[] image, uint address)
    {
        int pe = BitConverter.ToInt32(image, 0x3C);
        int count = BitConverter.ToUInt16(image, pe + 6);
        int sections = pe + 24 + BitConverter.ToUInt16(image, pe + 20);
        for (int i = 0; i < count; i++)
        {
            int section = sections + i * 40;
            uint location = BitConverter.ToUInt32(image, section + 12);
            uint size = Math.Max(BitConverter.ToUInt32(image, section + 8),
                BitConverter.ToUInt32(image, section + 16));
            if (address >= location && address < location + size)
                return checked((int)(address - location + BitConverter.ToUInt32(image, section + 20)));
        }
        throw new InvalidDataException("Не удалось найти тело метода в файле.");
    }

    private static string Hash(byte[] bytes)
    {
        using (var sha = SHA256.Create())
            return BitConverter.ToString(sha.ComputeHash(bytes)).Replace("-", "");
    }
}
