@echo off
chcp 65001 >nul
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0TextOnly.ps1" -Mode Install %*
echo.
pause
