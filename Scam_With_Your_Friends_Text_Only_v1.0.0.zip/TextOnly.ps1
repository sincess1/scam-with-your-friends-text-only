﻿param(
    [ValidateSet('Install', 'Restore', 'Verify')]
    [string]$Mode = 'Install',
    [string]$GamePath
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
$package = $PSScriptRoot
$gameFile = 'Scam With Your Friends.exe'
$relativeAssembly = 'Scam With Your Friends_Data\Managed\Assembly-CSharp.dll'

function Get-Hash([string]$Path) {
    $sha = [Security.Cryptography.SHA256]::Create()
    $stream = [IO.File]::OpenRead($Path)
    try {
        [BitConverter]::ToString($sha.ComputeHash($stream)).Replace('-', '')
    }
    finally {
        $stream.Dispose()
        $sha.Dispose()
    }
}

function Find-Game([string]$Requested) {
    if ($Requested) {
        $found = (Get-Item -LiteralPath $Requested).FullName.TrimEnd('\')
        if (-not (Test-Path -LiteralPath (Join-Path $found $gameFile))) {
            throw 'В выбранной папке нет Scam With Your Friends.exe.'
        }
        return $found
    }
    $candidates = @()
    if (Test-Path -LiteralPath (Join-Path $package $gameFile)) {
        $candidates += $package
    }
    $steamRoots = @()
    foreach ($key in @('HKCU:\Software\Valve\Steam', 'HKLM:\SOFTWARE\WOW6432Node\Valve\Steam')) {
        if (Test-Path -LiteralPath $key) {
            $settings = Get-ItemProperty -LiteralPath $key
            foreach ($property in @('SteamPath', 'InstallPath')) {
                if ($settings.PSObject.Properties.Name -contains $property) {
                    $steamRoots += $settings.$property
                }
            }
        }
    }
    $libraries = @($steamRoots)
    foreach ($steamRoot in $steamRoots | Select-Object -Unique) {
        $config = Join-Path $steamRoot 'steamapps\libraryfolders.vdf'
        if (Test-Path -LiteralPath $config) {
            foreach ($match in [regex]::Matches([IO.File]::ReadAllText($config), '"path"\s*"([^"]+)"')) {
                $libraries += $match.Groups[1].Value.Replace('\\', '\')
            }
        }
    }
    foreach ($library in $libraries | Select-Object -Unique) {
        $candidate = Join-Path $library 'steamapps\common\Scam With Your Friends'
        if (Test-Path -LiteralPath (Join-Path $candidate $gameFile)) {
            $candidates += $candidate
        }
    }
    $candidates = @($candidates | Select-Object -Unique)
    if ($candidates.Count -eq 1) {
        return (Get-Item -LiteralPath $candidates[0]).FullName.TrimEnd('\')
    }
    Add-Type -AssemblyName System.Windows.Forms
    $dialog = New-Object System.Windows.Forms.FolderBrowserDialog
    try {
        $dialog.Description = 'Выберите папку, в которой находится Scam With Your Friends.exe'
        $dialog.ShowNewFolderButton = $false
        if ($dialog.ShowDialog() -ne [System.Windows.Forms.DialogResult]::OK) {
            throw 'Операция отменена.'
        }
        return Find-Game $dialog.SelectedPath
    }
    finally {
        $dialog.Dispose()
    }
}

function Confirm-Stopped([string]$Root) {
    $expected = Join-Path $Root $gameFile
    foreach ($process in [Diagnostics.Process]::GetProcessesByName('Scam With Your Friends')) {
        try {
            $executable = $process.MainModule.FileName
        }
        catch {
            throw 'Не удалось проверить состояние игры. Закройте игру и повторите операцию.'
        }
        if ($executable -eq $expected) {
            throw 'Закройте Scam With Your Friends и повторите операцию.'
        }
    }
}

function Replace-Assembly([string]$Source, [string]$Target, [string]$Hash) {
    $stage = $Target + '.text-only.tmp'
    if (Test-Path -LiteralPath $stage) {
        throw 'Найдена незавершённая замена файла. Исходный файл не изменён.'
    }
    $created = $false
    try {
        [IO.File]::Copy($Source, $stage, $false)
        $created = $true
        if ((Get-Hash $stage) -ne $Hash) {
            throw 'Не совпадает контрольная сумма подготовленного файла.'
        }
        Confirm-Stopped $GamePath
        [IO.File]::Replace($stage, $Target, [NullString]::Value)
        if ((Get-Hash $Target) -ne $Hash) {
            throw 'Не совпадает контрольная сумма установленного файла.'
        }
    }
    finally {
        if ($created -and (Test-Path -LiteralPath $stage)) {
            [IO.File]::Delete($stage)
        }
    }
}

$GamePath = Find-Game $GamePath
$target = Join-Path $GamePath $relativeAssembly
$runtime = Join-Path (Split-Path -Parent $target) 'ScamTextOnly.Runtime.dll'
$backup = Join-Path $GamePath 'TextOnlyBackup'
$backupManifest = Join-Path $backup 'manifest.json'
$original = Join-Path $backup 'Assembly-CSharp.original.dll'
$currentHash = Get-Hash $target

if ($Mode -ne 'Install') {
    if (-not (Test-Path -LiteralPath $backupManifest)) {
        throw 'Резервная копия этого мода не найдена. Файлы игры не изменены.'
    }
    $saved = Get-Content -LiteralPath $backupManifest -Raw | ConvertFrom-Json
    if ($saved.Version -ne 1 -or (Get-Hash $original) -ne $saved.OriginalSha256) {
        throw 'Резервная копия повреждена. Файлы игры не изменены.'
    }
    if ($currentHash -ne $saved.OriginalSha256 -and $currentHash -ne $saved.PatchedSha256) {
        throw 'Игра обновлена или изменена другим модом. Откат остановлен, чтобы не заменить чужие изменения.'
    }
    if ($Mode -eq 'Verify') {
        if ($currentHash -eq $saved.PatchedSha256 -and
            (-not (Test-Path -LiteralPath $runtime) -or (Get-Hash $runtime) -ne $saved.RuntimeSha256)) {
            throw 'Не найден или изменён файл баннеров мода.'
        }
        Write-Output 'Файл игры и резервная копия проверены.'
        exit
    }
    Confirm-Stopped $GamePath
    if ((Test-Path -LiteralPath $runtime) -and (Get-Hash $runtime) -ne $saved.RuntimeSha256) {
        throw 'Файл баннеров изменён. Автоматическое удаление остановлено.'
    }
    if ($currentHash -ne $saved.OriginalSha256) {
        Replace-Assembly $original $target $saved.OriginalSha256
    }
    if (Test-Path -LiteralPath $runtime) {
        [IO.File]::Delete($runtime)
    }
    Write-Output 'Мод отключён. Исходная озвучка восстановлена. Сохранения и резервная копия оставлены на месте.'
    exit
}

Confirm-Stopped $GamePath
$release = Get-Content -LiteralPath (Join-Path $package 'release.json') -Raw -Encoding UTF8 | ConvertFrom-Json
if (Test-Path -LiteralPath $backupManifest) {
    $saved = Get-Content -LiteralPath $backupManifest -Raw | ConvertFrom-Json
    if ($saved.Version -ne 1 -or $saved.OriginalSha256 -ne $release.OriginalSha256 -or
        (Get-Hash $original) -ne $saved.OriginalSha256) {
        throw 'Найдена другая или повреждённая резервная копия. Она не перезаписана.'
    }
    if ($currentHash -eq $release.PatchedSha256 -and
        (Test-Path -LiteralPath $runtime) -and (Get-Hash $runtime) -eq $release.RuntimeSha256 -and
        (Get-Hash $original) -eq $release.OriginalSha256) {
        Write-Output 'Эта версия мода уже установлена. Повторная установка не требуется.'
        exit
    }
}
if ($currentHash -ne $release.OriginalSha256) {
    throw 'Эта сборка игры не поддерживается или уже изменена. Ничего не заменено. Проверьте актуальную версию мода на GitHub.'
}
if ((Test-Path -LiteralPath $runtime) -and (Get-Hash $runtime) -ne $release.RuntimeSha256) {
    throw 'В игре уже есть другой файл ScamTextOnly.Runtime.dll. Он не перезаписан.'
}
foreach ($file in $release.Files) {
    $path = Join-Path $package $file.Path
    if ((Get-Hash $path) -ne $file.Sha256) {
        throw ('Файл архива повреждён: ' + $file.Path)
    }
}
$compiler = Join-Path $env:WINDIR 'Microsoft.NET\Framework64\v4.0.30319\csc.exe'
if (-not (Test-Path -LiteralPath $compiler)) {
    throw 'Не найден штатный компонент .NET Framework Windows. Установка остановлена.'
}
$temporary = Join-Path ([IO.Path]::GetTempPath()) ('scam-text-only-' + [Guid]::NewGuid().ToString('N'))
New-Item -ItemType Directory -Path $temporary | Out-Null
$built = Join-Path $temporary 'ScamTextOnly.exe'
$candidate = Join-Path $temporary 'Assembly-CSharp.text-only.dll'
$runtimeSource = Join-Path $package 'lib\ScamTextOnly.Runtime.dll'
try {
    $cecil = Join-Path $temporary 'Mono.Cecil.dll'
    [IO.File]::Copy((Join-Path $package 'lib\Mono.Cecil.dll'), $cecil, $false)
    Write-Output 'Проверяем и подготавливаем мод...'
    & $compiler /nologo /optimize+ /codepage:65001 /target:exe ('/reference:' + $cecil) ('/out:' + $built) (Join-Path $package 'lib\ScamTextOnly.cs')
    if ($LASTEXITCODE -ne 0) {
        throw 'Не удалось подготовить установку. Файлы игры не изменены.'
    }
    & $built $target $candidate $runtimeSource (Split-Path -Parent $target)
    if ($LASTEXITCODE -ne 0 -or (Get-Hash $candidate) -ne $release.PatchedSha256) {
        throw 'Подготовленный файл не прошёл проверку. Файлы игры не изменены.'
    }
    if (-not (Test-Path -LiteralPath $backup)) {
        New-Item -ItemType Directory -Path $backup | Out-Null
    }
    if (Test-Path -LiteralPath $original) {
        if ((Get-Hash $original) -ne $release.OriginalSha256) {
            throw 'В папке резервной копии уже есть другой оригинал. Он не перезаписан.'
        }
    }
    else {
        [IO.File]::Copy($target, $original, $false)
    }
    if ((Get-Hash $original) -ne $release.OriginalSha256) {
        throw 'Не удалось проверить исходный файл в резервной копии.'
    }
    $saveRoot = Join-Path $env:USERPROFILE 'AppData\LocalLow\Jatater Worldwide\Scam With Your Friends\DaySaves'
    $saveBackup = Join-Path $backup 'DaySaves'
    if ((Test-Path -LiteralPath $saveRoot) -and -not (Test-Path -LiteralPath $saveBackup)) {
        Copy-Item -LiteralPath $saveRoot -Destination $saveBackup -Recurse
        foreach ($file in Get-ChildItem -LiteralPath $saveRoot -File -Recurse) {
            $relative = $file.FullName.Substring($saveRoot.Length + 1)
            if ((Get-Hash $file.FullName) -ne (Get-Hash (Join-Path $saveBackup $relative))) {
                throw 'Не удалось проверить резервную копию сохранения.'
            }
        }
    }
    [ordered]@{
        Version = 1
        ModVersion = $release.Version
        OriginalSha256 = $release.OriginalSha256
        PatchedSha256 = $release.PatchedSha256
        RuntimeSha256 = $release.RuntimeSha256
    } | ConvertTo-Json | Set-Content -LiteralPath $backupManifest -Encoding UTF8
    Copy-Item -LiteralPath $PSCommandPath -Destination (Join-Path $backup 'TextOnly.ps1') -Force
    $rollback = '@echo off' + [Environment]::NewLine +
        'powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0TextOnly.ps1" -Mode Restore -GamePath "%~dp0.."' +
        [Environment]::NewLine + 'pause' + [Environment]::NewLine
    [IO.File]::WriteAllText((Join-Path $backup 'Restore.cmd'), $rollback, [Text.Encoding]::ASCII)
    $addedRuntime = -not (Test-Path -LiteralPath $runtime)
    try {
        if ($addedRuntime) {
            [IO.File]::Copy($runtimeSource, $runtime, $false)
        }
        Replace-Assembly $candidate $target $release.PatchedSha256
    }
    catch {
        if ($addedRuntime -and (Test-Path -LiteralPath $runtime) -and
            (Get-Hash $target) -eq $release.OriginalSha256 -and
            (Get-Hash $runtime) -eq $release.RuntimeSha256) {
            [IO.File]::Delete($runtime)
        }
        throw
    }
    Write-Output ''
    Write-Output 'Готово. Запускайте игру обычным способом через Steam.'
    Write-Output 'Голос собеседников отключён, ответы выводятся целиком.'
    Write-Output 'Для отката запустите «Откатить.cmd» или TextOnlyBackup\Restore.cmd в папке игры.'
    Write-Output 'Мод бесплатный. В меню есть отдельная ссылка SteamGate.online.'
}
finally {
    foreach ($name in @('ScamTextOnly.exe', 'Mono.Cecil.dll', 'Assembly-CSharp.text-only.dll')) {
        $path = Join-Path $temporary $name
        if (Test-Path -LiteralPath $path) {
            [IO.File]::Delete($path)
        }
    }
    [IO.Directory]::Delete($temporary)
}
